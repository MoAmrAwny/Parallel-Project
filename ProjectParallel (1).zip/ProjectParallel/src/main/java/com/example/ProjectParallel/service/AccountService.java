package com.example.ProjectParallel.service;

import org.springframework.stereotype.Service;

@Service
public class AccountService {

//    @Autowired
//    private ItemRepo repo;

//    public List<Item> getAllProducts() {
//        return repo.findAll();
//    }
//
//    public Item getProductById(int id) {
//        return repo.findById(id).orElse(null);
//        //return repo.findById(id).get();
//    }
}
