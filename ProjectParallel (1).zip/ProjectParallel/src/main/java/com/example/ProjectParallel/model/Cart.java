package com.example.ProjectParallel.model;

import jakarta.persistence.*;
@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartId;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accId", referencedColumnName = "accId")
    private Account CartOwner;

    @OneToOne(mappedBy = "cart")
    private CartItem cartItem;
    private float TotalPrice;
    public Cart(){}
    public Cart(int cartId,float totalPrice, Account CartOwner) {
        this.cartId = cartId;
        TotalPrice = totalPrice;
        this.CartOwner=CartOwner;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "cartId=" + cartId +
                ", CartOwnerId=" + CartOwner.getAccId() +
                ", TotalPrice=" + TotalPrice +
                '}';
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public float getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        TotalPrice = totalPrice;
    }

    public Account getCartOwner() {
        return CartOwner;
    }

    public void setCartOwner(Account cartOwner) {
        CartOwner = cartOwner;
    }

    public CartItem getCartItem() {
        return cartItem;
    }

    public void setCartItem(CartItem cartItem) {
        this.cartItem = cartItem;
    }
}
