package com.example.ProjectParallel.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AccountController {

//    @Autowired
//    private ItemService service;
//
//    @GetMapping("/")
//    public String greet(){
//        return "Hello jana";
//    }
//
//    @GetMapping("/products")
//    public ResponseEntity<List<Item>> getAllProducts(){
//        return new ResponseEntity<>(service.getAllProducts(), HttpStatus.OK);
//    }
//
//    @GetMapping("/products/{id}")
//    public ResponseEntity<Item> getProduct(@PathVariable int id){
//        Item itm= service.getProductById(id);
//        if(itm!=null){
//            return new ResponseEntity<>(itm,HttpStatus.OK);
//        }
//        else{
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }
}
