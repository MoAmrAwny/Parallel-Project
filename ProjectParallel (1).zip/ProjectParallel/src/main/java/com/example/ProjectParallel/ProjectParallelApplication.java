package com.example.ProjectParallel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectParallelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectParallelApplication.class, args);

	}

}
