package com.jana.pp3;

import com.jana.pp3.model.primarydbmodel.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class ItemController {

    @Autowired
    private ItemService service;

    @GetMapping("/products")
    public List<Item> getAllItems() {
        return service.getAllProducts();
    }

    @PostMapping
    public Item createItem(@RequestBody Item item) {
        return service.save(item);
    }
}

