package com.jana.pp3;
import com.jana.pp3.model.primarydbmodel.Item;
import com.jana.pp3.repo.primary.PrimaryItemRepository;
import com.jana.pp3.repo.secondary.SecondaryItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    private final PrimaryItemRepository primaryRepo;
    private final SecondaryItemRepository secondaryRepo;

    @Autowired
    public ItemService(PrimaryItemRepository primaryRepo, SecondaryItemRepository secondaryRepo) {
        this.primaryRepo = primaryRepo;
        this.secondaryRepo = secondaryRepo;
    }

    public List<Item> getAllProducts(){
       ArrayList<Item> items=new ArrayList<>();
       items.addAll(primaryRepo.findAll());
       items.addAll(secondaryRepo.findAll());
       return items;
    }

    public Item save(Item item) {
        if (item.getItemId() % 2 == 0) {
            return primaryRepo.save(item);
        } else {
            return secondaryRepo.save(item);
        }
    }

    public Optional<Item> findById(Integer id) {
        if (id % 2 == 0) {
            return primaryRepo.findById(id);
        } else {
            return secondaryRepo.findById(id);
        }
    }

    public void deleteById(Integer id) {
        if (id % 2 == 0) {
            primaryRepo.deleteById(id);
        } else {
            secondaryRepo.deleteById(id);
        }
    }
}
