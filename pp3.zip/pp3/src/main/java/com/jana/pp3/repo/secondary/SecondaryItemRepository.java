package com.jana.pp3.repo.secondary;

import com.jana.pp3.model.primarydbmodel.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SecondaryItemRepository extends JpaRepository<Item, Integer> {
}

