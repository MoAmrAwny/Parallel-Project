package com.jana.pp3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
