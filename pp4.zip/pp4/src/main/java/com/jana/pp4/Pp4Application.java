package com.jana.pp4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pp4Application {

	public static void main(String[] args) {
		SpringApplication.run(Pp4Application.class, args);
	}

}
