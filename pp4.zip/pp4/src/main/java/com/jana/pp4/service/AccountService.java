package com.jana.pp4.service;

import com.jana.pp4.model.Account;
import com.jana.pp4.model.DepositLog;
import com.jana.pp4.model.Item;
import com.jana.pp4.model.TransactionItem;
import com.jana.pp4.repo.primaryrepo.PrimaryAccountRepo;
import com.jana.pp4.repo.secondaryrepo.SecondaryAccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountService {
    @Autowired
    private PrimaryAccountRepo primaryRepo;
    @Autowired
    private SecondaryAccountRepo secondaryRepo;
    @Autowired
    private DepositLogService depositService;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private TransactionItemService transactionItemService;
    @Autowired
    private ItemService itemService;

    public BigDecimal ViewBalance(Integer id) {
        if(id%2==0){  //even
            Account acc=secondaryRepo.findById(id).
                    orElseThrow(() -> new RuntimeException("Account not found"));
            return acc.getBalance();
        }
        else{
            Account acc=primaryRepo.findById(id).
                    orElseThrow(() -> new RuntimeException("Account not found"));
            return acc.getBalance();
        }
    }
    public void depositAmount(BigDecimal num, Integer id) {
        if(id%2==0){
            Account acc=secondaryRepo.findById(id).
                    orElseThrow(() -> new RuntimeException("Account not found"));
            acc.setBalance(acc.getBalance().add(num));
            secondaryRepo.save(acc);
            depositService.addDepositLog(num,acc);
        }
        else{
            Account acc=primaryRepo.findById(id).
                    orElseThrow(() -> new RuntimeException("Account not found"));
            acc.setBalance(acc.getBalance().add(num));
            primaryRepo.save(acc);
            depositService.addDepositLog(num,acc);
        }
    }
    @Transactional(readOnly = true)
    public List<DepositLogDto> viewDepositLog(Integer id) {
        // 1. Get the account with deposit logs loaded
        Account account = (id % 2 == 0)
                ? secondaryRepo.findAccountWithDepositLogsById(id)
                .orElseThrow(() -> new RuntimeException("Account not found"))
                : primaryRepo.findAccountWithDepositLogsById(id)
                .orElseThrow(() -> new RuntimeException("Account not found"));
        // 2. Convert to DTOs
        return account.getDepositLogs().stream()
                .map(log -> new DepositLogDto(log.getDepositedAmt(), log.getLogTime()))
                .collect(Collectors.toList());
    }
    public List<TransactionService.PurchasedItemDTO> viewPurchasedItems(Integer id) {
        return transactionService.getTransactionItems(id);
    }
    public List<TransactionItemService.SoldItemDTO> viewSoldItems(Integer id) {
        return transactionItemService.getSoldItems(id);
    }
    public List<ItemService.ItemDTO> viewNotSoldItems(Integer id) {
        return itemService.getItemById(id);
    }

    public static class DepositLogDto {
        private BigDecimal depositedAmt;
        private Date logTime;
        public DepositLogDto(BigDecimal depositedAmt, Date logTime) {
            this.depositedAmt = depositedAmt;
            this.logTime = logTime;
        }
        // Getters
        public BigDecimal getDepositedAmt() { return depositedAmt; }
        public Date getLogTime() { return logTime; }
    }
}
