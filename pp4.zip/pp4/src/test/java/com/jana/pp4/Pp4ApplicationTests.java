package com.jana.pp4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pp4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
